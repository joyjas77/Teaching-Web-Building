<html>
<head>
<title> Example 4-2. Outputting the values of TRUE and FALSE</title>
</head>
<body>
<?php 
echo "a: [" . TRUE . "]<br />";
echo "b: [" . FALSE . "]<br />";
?>
</body>
</html>