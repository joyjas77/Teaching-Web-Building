<html>
<head>
<title> Example 4-12. Assigning a value and testing for equality</title>
</head>
<body>
<?php
$month = "March";
if ($month == "March") echo "It's springtime";
?>
</body>
</html>