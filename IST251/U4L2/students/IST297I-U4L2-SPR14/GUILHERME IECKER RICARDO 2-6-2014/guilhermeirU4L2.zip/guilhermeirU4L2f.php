<html>
<head>
<title> Challenge #2! </title>
</head>
<body>
<?php
$i = 1;
for ($i; $i <= 10; $i++)
echo "$i times 5 is " . 5*$i . "<br>";
?>
</body>
</html>