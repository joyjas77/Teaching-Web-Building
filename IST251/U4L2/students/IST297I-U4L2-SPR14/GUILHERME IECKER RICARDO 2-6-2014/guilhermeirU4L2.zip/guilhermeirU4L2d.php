<html>
<head>
<title> Example 4-13.The equality and identity operators</title>
</head>
<body>
<?php
$a = "1000";
$b = "+1000";
if ($a == $b) echo "1";
if ($a === $b) echo "2";
?>
</body>
</html>