<html>
<head>
<title> Example 4-1. Four Simple Boolean Expressions</title>
</head>
<body>
<?php 
echo "a: [" . (20>9) . "]<br />";
echo "b: [" . (5==6) . "]<br />";
echo "c: [" . (1==0) . "]<br />";
echo "d: [" . (1==1) . "]<br />";
?>
</body>
</html>