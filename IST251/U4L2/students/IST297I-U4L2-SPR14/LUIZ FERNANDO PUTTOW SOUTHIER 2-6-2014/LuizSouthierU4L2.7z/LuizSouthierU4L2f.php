<html>
<head>
<title>Example 2</title>
</head>
<body>
<?php
$a = "1000";
$b = "+1000";
if ($a == $b) echo "1";
if ($a === $b) echo "2";
?>
</body>
</html>
