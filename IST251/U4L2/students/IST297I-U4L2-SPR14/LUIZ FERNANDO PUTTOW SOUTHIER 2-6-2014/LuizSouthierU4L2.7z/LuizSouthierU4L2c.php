<html>
<head>
<title>Example 4</title>
</head>
<body>
<?php
$fuel = 1;
echo $fuel <= 1 ? "Fill tank now" : "There's enough fuel";

$fuel = 20;
echo $fuel <= 1 ? "Fill tank now" : "There's enough fuel";
?>
</body>
</html>
