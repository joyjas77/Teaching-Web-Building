<html>
<head>
<title>Challenge</title>
</head>
<body>
<?php

for ($count=0;$count<10; $count++)
{
  
  echo  $count*1.2 . "<br />";
}
?>
</body>
</html>
