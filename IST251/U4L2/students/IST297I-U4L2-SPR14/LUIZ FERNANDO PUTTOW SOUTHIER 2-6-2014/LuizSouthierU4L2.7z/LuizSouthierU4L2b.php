<html>
<head>
<title>Example 3</title>
</head>
<body>
<?php
$a = 1; $b = 0;
echo ($a AND $b) . "<br />";
echo ($a or $b) . "<br />";
echo ($a XOR $b) . "<br />";
echo !$a . "<br />";
?>
</body>
</html>
