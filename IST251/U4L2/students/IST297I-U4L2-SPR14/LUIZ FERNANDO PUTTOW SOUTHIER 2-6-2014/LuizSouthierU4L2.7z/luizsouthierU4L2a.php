<html>
<head>
<title>Example 1</title>
</head>
<body>
<?php
$myname = "Luiz";
$myage = 21;
echo "a: " . 73 . "<br />"; // Numeric literal
echo "b: " . "Hey" . "<br />"; // String literal
echo "c: " . FALSE . "<br />"; // Constant literal
echo "d: " . $myname . "<br />"; // Variable string literal
echo "e: " . $myage . "<br />"; // Variable numeric literal
?>
</body>
</html>
