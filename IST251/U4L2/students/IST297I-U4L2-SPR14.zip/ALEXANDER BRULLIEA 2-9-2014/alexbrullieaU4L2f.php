<?php
//the same as alexbrullieaU4L2d but uses the for loop instead
for ($count = 1 ; $count <= 12 ; ++$count) //creates a for loop, sets count = 1, runs while count is <= 12 and increments count by 1
{
	echo "$count times 12 is " . $count * 12; //Multiplies count by 12 and outputs it
	echo "<br />"; //breaks to the next line
}
?>
