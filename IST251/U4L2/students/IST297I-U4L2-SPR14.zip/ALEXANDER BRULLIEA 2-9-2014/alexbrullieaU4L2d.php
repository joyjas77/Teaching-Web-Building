<?php
$count = 0; //Sets count equal to 0
while (++$count <= 12) //while count is less than or equal to 12, this runs. it also adds 1 to count before each run
{
	echo "$count times 12 is " . $count * 12 . "<br />"; //multiplies 12 by count each run through and outputs
}
?>
