<?php
//If the equation is true it will output a 1. If false, no number will be output in the brackets
echo "a: [" . (20 > 9) . "]<br />"; //True statement
echo "b: [" . (5 == 6) . "]<br />"; //False statement
echo "c: [" . (1 == 0) . "]<br />"; //False statement
echo "d: [" . (1 == 1) . "]<br />"; //True statement
?>
