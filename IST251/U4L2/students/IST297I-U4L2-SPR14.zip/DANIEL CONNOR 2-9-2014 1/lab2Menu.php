<br><br><br><br><br><br>
<div>
	<h3>Lab 2 Menu</h3>
	<a style="text-decoration: underline; text-align:center" href="http://my.up.ist.psu.edu/dic5232/ist297/lab2/danconnorU4L2a.php">example 1</a><br>
	<a style="text-decoration: underline; text-align:center" href="http://my.up.ist.psu.edu/dic5232/ist297/lab2/danconnorU4L2b.php">example 2</a><br>
	<a style="text-decoration: underline; text-align:center" href="http://my.up.ist.psu.edu/dic5232/ist297/lab2/danconnorU4L2c.php">example 3</a><br>
	<a style="text-decoration: underline; text-align:center" href="http://my.up.ist.psu.edu/dic5232/ist297/lab2/danconnorU4L2d.php">example 4</a><br>
	<a style="text-decoration: underline; text-align:center" href="http://my.up.ist.psu.edu/dic5232/ist297/lab2/danconnorU4L2e.php">example 5</a><br>
	<a style="text-decoration: underline; text-align:center" href="http://my.up.ist.psu.edu/dic5232/ist297/lab2/danconnorU4L2challenge.php">challenge</a>
</div>