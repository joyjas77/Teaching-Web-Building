<html>
	<head><title>Lab 2 Example B</title></head>
	<body>
		<!-- Unit 3 Lab 4 Example 4-3 -->
		<?php
		$myname = "Brian";
		$myage = 37;
		echo "a: ". 73       . "<br>"; //Numeric Literal
		echo "b: ". "Hello"  . "<br>"; //String Literal
		echo "c: ". FALSE    . "<br>"; //Constant Literal
		echo "d: ". $myname  . "<br>"; //Variable string literal
		echo "e: ". $myage   . "<br>"; //Variable numeric literal
		?>
		<?php include "lab2Menu.php"?>
	</body>
</html>