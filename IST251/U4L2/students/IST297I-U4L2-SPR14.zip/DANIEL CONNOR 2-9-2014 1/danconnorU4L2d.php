<html>
	<head><title>Lab 2 Example D</title></head>
	<body>
		<!-- Unit 3 Lab 4 Example 4-16 -->
		<?php
		$a = 1; $b = 0;
		echo ($a AND $b) . "<br>";
		echo ($a or $b) . "<br>";
		echo ($a XOR $b) . "<br>";
		echo !$a . "<br>";
		?>
		<?php include "lab2Menu.php"?>
	</body>
</html>