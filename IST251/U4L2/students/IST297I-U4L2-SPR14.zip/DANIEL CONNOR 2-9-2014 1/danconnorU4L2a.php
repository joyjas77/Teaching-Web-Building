<html>
	<head><title>Lab 2 Example A</title></head>
	<body>
		<!-- Unit 3 Lab 4 Example 4-1 -->
		<?php
		echo "a: [". (20 > 9) . "] <br>";
		echo "b: [". (5 == 6) . "] <br>";
		echo "c: [". (1 == 0) . "] <br>";
		echo "d: [". (1 == 1) . "] <br>";
		?>
		<?php include "lab2Menu.php"?>
	</body>
</html>
