<!DOCTYPE HTML>
<html>
	<head>
		<title>Lab 1, example 3</title>
	</head>
	<body>
		<?php //example 3-7, page 52
		$author = "Alfred E Newman";
		$text = "This is a Headline
				
		This is the first line.
		This is the second.
		Written by $author.";
		echo "Note: This is an example without a printed result."
		?>
		<?php include 'lab1menu.php';?>
	</body>
</html>
