<!DOCTYPE HTML>
<html>
	<head>
		<title>Lab 1 Challenge</title>
	</head>
	<body>
		<?php //Prints 2nd element of array 
		$colorArray = array("Red", "Green", "Blue", "Yellow");
		echo "The second element in the color array is: $colorArray[1]";
		?>
		<?php include 'lab1menu.php';?>
	</body>
</html>