<br><br><br><br><br><br>
<div>
	<h3>Lab 1 Menu</h3>
	<a style="text-decoration: underline; text-align:center" href="http://my.up.ist.psu.edu/dic5232/ist297/lab1/danconnorU3L1a.php">example 1</a><br>
	<a style="text-decoration: underline; text-align:center" href="http://my.up.ist.psu.edu/dic5232/ist297/lab1/danconnorU3L1b.php">example 2</a><br>
	<a style="text-decoration: underline; text-align:center" href="http://my.up.ist.psu.edu/dic5232/ist297/lab1/danconnorU3L1c.php">example 3</a><br>
	<a style="text-decoration: underline; text-align:center" href="http://my.up.ist.psu.edu/dic5232/ist297/lab1/danconnorU3L1d.php">example 4</a><br>
	<a style="text-decoration: underline; text-align:center" href="http://my.up.ist.psu.edu/dic5232/ist297/lab1/danconnorU3L1e.php">example 5</a><br>
	<a style="text-decoration: underline; text-align:center" href="http://my.up.ist.psu.edu/dic5232/ist297/lab1/danconnorU3L1challenge.php">challenge</a>
</div>