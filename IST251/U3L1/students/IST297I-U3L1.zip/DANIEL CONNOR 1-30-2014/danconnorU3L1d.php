<!DOCTYPE HTML>
<html>
	<head>
		<title>Lab 1, example 4</title>
	</head>
	<body>
		<?php //example 3-10, page 53
		$number = 12345 * 67890;
		echo substr($number, 3, 1);
		?>
		<?php include 'lab1menu.php';?>
	</body>
</html>