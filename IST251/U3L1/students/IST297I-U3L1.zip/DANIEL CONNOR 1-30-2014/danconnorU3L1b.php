<!DOCTYPE HTML>
<html>
	<head>
		<title>Lab 1, example 2</title>
	</head>
	<body>
		<?php //example 3-6, page 52
		$author = "Alfred E Newman";
		echo "This is a Headline
				
		This is the first line.
		This is the second.
		Written by $author.";
		?>
		<?php include 'lab1menu.php';?>
	</body>
</html>
