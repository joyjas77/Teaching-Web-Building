<!DOCTYPE HTML>
<html>
	<head>
		<title>Lab 1, example 1</title>
	</head>
	<body>
		<?php //example 3-4, page 43
		$username = "Fred Smith";
		echo $username;
		echo "<br />";
		$current_user = $username;
		echo $current_user;
		?>
		<?php include 'lab1menu.php';?>
	</body>
</html>
