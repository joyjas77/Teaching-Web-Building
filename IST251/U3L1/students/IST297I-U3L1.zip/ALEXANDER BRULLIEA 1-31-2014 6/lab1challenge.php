<?php
$myarray = array("one","two","three","four");
echo $myarray[1];
?>
