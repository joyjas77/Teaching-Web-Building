<html>
<head>
<title> The Challenge! </title>
</head>
<body>
<?php 
$myarray = array("One", "Two", "Three", "Four");
echo $myarray[1];
?>
</body>
</html>