<html>
<head>
<title> Example 3-4. Your first PHP program</title>
</head>
<body>
<?php
$username = "Guilherme Iecker Ricardo";
echo $username;
echo"<br />";
$current_user = $username;
echo $current_user;
?>
</body>
</html>