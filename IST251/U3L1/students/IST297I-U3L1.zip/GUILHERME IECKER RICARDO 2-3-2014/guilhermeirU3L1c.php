<html>
<head>
<title> Example 3-11. Automatically converting a string to a number</title>
</head>
<body>
<?php
$pi = "3.1415927";
$radius = 5;
echo $pi * ($radius * $radius);
?>
</body>
</html>