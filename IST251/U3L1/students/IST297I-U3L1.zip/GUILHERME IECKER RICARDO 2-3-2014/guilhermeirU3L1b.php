<html>
<head>
<title> Example 3-10. Automatic conversion from a number to a string</title>
</head>
<body>
<?php
$number = 12345 * 67890;
echo substr($number, 3, 1);
?>
</body>
</html>