<?php // 3-6
$author="Alfred E Newman";

echo "This is a Headline

This is the first line.
This is the second.
Written by $author.";
?>
