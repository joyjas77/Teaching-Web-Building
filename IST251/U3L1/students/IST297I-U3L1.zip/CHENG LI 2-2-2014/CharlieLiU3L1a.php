<?php // 3-1
echo "Hello world";
?>
