<?php
$stuff=array('foo', 9, 'bar', 'IBM Model M');
echo $stuff[1];
?>
