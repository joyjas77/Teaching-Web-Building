<?php

//3-1
echo "hello world";

//3-2
/* This is a section
   of multiline comments
   that will not be 
   interpreted */

//3-3
$mycounter = 1;
$mystring = "Hello";
$myarray = array("One", "Two", "Three");

//3-4
$username = "Fred Smith";
echo $username;
echo "<br />";
$current_user = $username;
echo $current_user;

//3-5
$oxo = array( array('x', '', 'o'),
              array('o', 'o', 'x'),
              array('x', 'o', ''));

//Challenge
$challenge = array('one', 'two', 'three', 'four');
echo $challenge[1];
?>