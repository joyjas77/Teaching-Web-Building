<html lang="en">
  <head>
	<!--[if gte IE 9]>
	<style type="text/css">
    .gradient {
       filter: none;
    }
		</style>
	<![endif]-->
    <title>IST 251</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="IST250 Space Website Design">
    <meta name="author" content="Sly5051 Steven Yencho">
    <!-- Bootstrap -->
    <link href="css/bootstrap.css" rel="stylesheet" media="screen">
	<link href="css/custom.css" rel="stylesheet" media="screen">
	<script src="js/jquery.js"></script>
	<link href="css/bootstrap-responsive.css" rel="stylesheet">
	<script src="js/bootstrap.js"></script>
  </head>
<body>
    <div class="container">
        <div class="masthead">
            <h3 class="text-muted"><a href="index.php">IST 297I - 251 PHP Environment</a></h3>
            <ul class="nav nav-justified">
                <li class="active">
                    <a href="index.php">Home</a>
                </li>
                <li>
                    <a href="stevenyenchoU3L1.php">Lab 1</a>
                </li>
                <li>
                    <a href="#">Lab 2</a>
                </li>
                <li>
                    <a href="#">Lab 3</a>
                </li>
                <li>
                    <a href="#">Lab 4</a>
                </li>
            </ul>
        </div>