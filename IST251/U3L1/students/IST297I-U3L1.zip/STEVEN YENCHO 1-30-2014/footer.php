<footer>
			<p>&copy;sly5051@psu.edu <a href="./index.php" >Home </a><a href="#"> About </a><a href="#"> Sitemap </a></p><!--TODO NOT REQUIRED SITEMAP-->
		</footer>
	</div>	
  </body>
</html>