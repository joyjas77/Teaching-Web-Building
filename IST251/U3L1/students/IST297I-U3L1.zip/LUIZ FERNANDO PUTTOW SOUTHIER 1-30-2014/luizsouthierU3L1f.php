<html>
<head>
<title>Exemple 5</title>
</head>

<body>
<?php
$username = "Fred Smith";
echo $username;
echo "<br />";
$current_user = $username;
echo $current_user;
?>
</body>
</html>