<html>
<head>
<title>Exemple 3</title>
</head>

<body>
<?php
$author = "Alfred E Newman<br>";
echo "This is a Headline<br>
This is the first line.<br>
This is the second.<br>
Written by $author.";
?>
</body>
</html>