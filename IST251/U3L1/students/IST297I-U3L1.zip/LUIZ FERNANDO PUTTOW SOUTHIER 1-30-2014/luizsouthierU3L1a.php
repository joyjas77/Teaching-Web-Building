<html>
<head>
<title>Challenge</title>
</head>

<body>
<?php

$challenge = array("First", "Second", "Third", "Fourth");
echo $challenge[2];

?>
</body>
</html>