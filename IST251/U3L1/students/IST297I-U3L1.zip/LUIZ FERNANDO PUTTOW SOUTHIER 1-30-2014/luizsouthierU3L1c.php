<html>
<head>
<title>Example 2</title>
</head>

<body>
<?php
$pi = "3.1415927";
$radius = 5;
echo $pi * ($radius * $radius);
?>

</body>
</html>