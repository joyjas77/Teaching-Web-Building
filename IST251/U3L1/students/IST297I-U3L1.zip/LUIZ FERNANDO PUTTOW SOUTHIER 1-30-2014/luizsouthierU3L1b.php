<html>
<head>
<title>Exemple 1</title>
</head>

<body>
<?php
$oxo = array(array('x', '', 'o'),
array('o', 'o', 'x'),
array('x', 'o', '' ));

echo $oxo[1][2];
?>


</body>
</html>